# -*- coding: utf-8 -*-
"""SportPlay v2 - Librairie complete"""
import sys, os, re, time, json, sqlite3, threading, requests, hashlib
from datetime import datetime
from urllib.parse import urlencode, quote, unquote, parse_qsl

import xbmc, xbmcvfs, xbmcaddon, xbmcgui, xbmcplugin

# ============================================================
# GLOBALS
# ============================================================
ADDON_ID = "plugin.video.sportplay"
ADDON = xbmcaddon.Addon(ADDON_ID)
ADDON_PATH = xbmcvfs.translatePath("special://home/addons/%s/" % ADDON_ID)
ADDON_DATA = xbmcvfs.translatePath("special://home/userdata/addon_data/%s/" % ADDON_ID)
DB_PATH = os.path.join(ADDON_DATA, "sportplay.db")
if not os.path.exists(ADDON_DATA):
    os.makedirs(ADDON_DATA)

def HANDLE():
    return int(sys.argv[1])

# ============================================================
# LOGGING / NOTIFICATIONS
# ============================================================
def log(msg, level=xbmc.LOGINFO):
    xbmc.log("%s: %s" % (ADDON_ID, str(msg)), level)

def notify(msg, icon=xbmcgui.NOTIFICATION_INFO, dur=4000):
    xbmcgui.Dialog().notification("SportPlay", msg, icon, dur)

def notify_err(msg):
    notify(msg, xbmcgui.NOTIFICATION_ERROR)

# ============================================================
# SETTINGS
# ============================================================
def S(key, default=""):
    v = ADDON.getSetting(key); return v if v else default

def SB(key, default=False):
    v = ADDON.getSetting(key); return v.lower() != "false" if v else default

def SI(key, default=0):
    try: return int(ADDON.getSetting(key))
    except: return default

# ============================================================
# KODI VERSION + LISTITEM HELPERS
# ============================================================
_kv = None
def kodi_ver():
    global _kv
    if _kv is None:
        v = re.findall(r'(\d{2}[.]\d{1,2})', xbmc.getInfoLabel('System.BuildVersion'))
        _kv = float(v[0]) if v else 19.0
    return _kv

def set_info(li, d):
    if kodi_ver() >= 20.0:
        vi = li.getVideoInfoTag()
        if "title" in d: vi.setTitle(str(d["title"]))
        if "plot" in d: vi.setPlot(str(d["plot"]))
        if "year" in d:
            try: vi.setYear(int(str(d["year"])[:4]))
            except: pass
        if "genre" in d:
            g = d["genre"]; vi.setGenres(g if isinstance(g, list) else [g])
        if "mediatype" in d: vi.setMediaType(d["mediatype"])
    else:
        li.setInfo("video", {k: d[k] for k in d if k in ("title","plot","year","genre","mediatype")})

def _icon_path(name):
    """Resolve icon path from resources/icons/"""
    if not name: return ""
    if name.startswith("special://") or os.path.isabs(name): return name
    p = os.path.join(ADDON_PATH, "resources", "icons", name)
    if os.path.exists(p): return p
    # Fallback old path
    p2 = os.path.join(ADDON_PATH, "resources", "png", name)
    if os.path.exists(p2): return p2
    return ""

# Mapping competition name -> icon filename
COMP_ICONS = {
    "Ligue 1":"ligue_1","Premier League":"premier_league","La Liga":"la_liga",
    "Serie A":"serie_a","Bundesliga":"bundesliga","Champions League":"champions_league",
    "Europa League":"europa_league","Conference League":"europa_league",
    "Coupe du Monde":"coupe_du_monde","Euro":"euro","Coupe de France":"coupe_de_france",
    "NBA":"nba","NBA Playoffs":"nba_playoffs","NBA Finals":"nba_finals",
    "EuroLeague":"euroleague","FIBA":"fiba",
    "UFC":"ufc","UFC PPV":"ufc_ppv","UFC Fight Night":"ufc_fight_night",
    "Bellator":"bellator","ONE Championship":"one_championship","PFL":"pfl",
    "Boxe":"boxe","Boxe PPV":"boxe_ppv",
    "WWE":"wwe","WWE PPV":"wwe_ppv","AEW":"aew","AEW PPV":"aew_ppv","Catch":"catch",
    "Formule 1":"formule_1","Formule 2":"formule_2","Formule E":"formule_e","MotoGP":"motogp",
    "Moto2":"moto2","Moto3":"moto3","NASCAR Cup Series":"nascar_cup_series",
    "IndyCar":"indycar","WRC":"wrc","WEC":"wec","24H du Mans":"24h_du_mans","WSBK":"wsbk",
    "Roland Garros":"roland_garros","Wimbledon":"wimbledon","US Open":"us_open",
    "Open Australie":"open_australie","ATP Masters":"atp_masters","ATP Finals":"atp_finals",
    "Coupe Davis":"coupe_davis",
    "Top 14":"top_14","6 Nations":"6_nations","Champions Cup":"champions_cup",
    "Coupe du Monde Rugby":"coupe_du_monde_rugby",
    "NFL":"nfl","NFL Playoffs":"nfl_playoffs","Super Bowl":"super_bowl",
    "Tour de France":"tour_de_france","Giro":"giro","Vuelta":"vuelta",
    "Paris-Roubaix":"paris_roubaix","Classiques":"classiques",
}

def get_comp_icon(comp_name):
    """Get icon path for a competition name"""
    key = COMP_ICONS.get(comp_name, "")
    if key:
        p = _icon_path(key + ".png")
        if p: return p
    return ADDON.getAddonInfo("icon")

def get_sport_icon(sport_key):
    """Get icon path for a sport key"""
    sp = SPORTS.get(sport_key)
    if sp:
        p = _icon_path(sp.get("icon", ""))
        if p: return p
    return ADDON.getAddonInfo("icon")

def get_sport_fanart(sport_key):
    """Get fanart path for a sport key"""
    p = os.path.join(ADDON_PATH, "resources", "fanart", sport_key + ".jpg")
    if os.path.exists(p): return p
    return ADDON.getAddonInfo("fanart")

def add_item(name, action, params=None, icon="", fanart="", plot="", folder=True, playable=False):
    h = HANDLE()
    li = xbmcgui.ListItem(label=name)
    info = {"title": name, "mediatype": "video"}
    if plot: info["plot"] = plot
    set_info(li, info)
    thumb = _icon_path(icon) or ADDON.getAddonInfo("icon")
    fan = fanart or ADDON.getAddonInfo("fanart")
    li.setArt({"thumb": thumb, "icon": thumb, "fanart": fan})
    if playable: li.setProperty("IsPlayable", "true")
    p = {"action": action}
    if params: p.update(params)
    url = sys.argv[0] + "?" + urlencode(p)
    return xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=folder)

def end_dir(content="files", sorts=None):
    h = HANDLE()
    xbmcplugin.setContent(h, content)
    if sorts:
        for s in sorts: xbmcplugin.addSortMethod(h, s)
    xbmcplugin.endOfDirectory(handle=h, succeeded=True)

# ============================================================
# SPORTS CONFIG
# ============================================================
SPORTS = {
    "football": {
        "name": "Football", "icon": "football.png",
        "comps": ["Ligue 1","Premier League","La Liga","Serie A","Bundesliga",
                  "Champions League","Europa League","Conference League",
                  "Coupe du Monde","Euro","Coupe de France","Autre"]
    },
    "nba": {
        "name": "NBA / Basketball", "icon": "nba.png",
        "comps": ["NBA","NBA Playoffs","NBA Finals","EuroLeague","FIBA","Autre"]
    },
    "mma": {
        "name": "MMA / Boxe / Catch", "icon": "mma.png",
        "comps": ["UFC","UFC PPV","UFC Fight Night","Bellator","ONE Championship",
                  "PFL","Boxe","Boxe PPV","WWE","WWE PPV","AEW","AEW PPV","Catch","Autre"]
    },
    "motorsport": {
        "name": "Sports Mecaniques", "icon": "motorsport.png",
        "comps": ["Formule 1","Formule 2","Formule E","MotoGP","Moto2","Moto3",
                  "NASCAR Cup Series","IndyCar","WRC","WEC","24H du Mans",
                  "WSBK","Autre"]
    },
    "tennis": {
        "name": "Tennis", "icon": "tennis.png",
        "comps": ["Roland Garros","Wimbledon","US Open","Open Australie",
                  "ATP Masters","ATP Finals","Coupe Davis","Autre"]
    },
    "rugby": {
        "name": "Rugby", "icon": "rugby.png",
        "comps": ["Top 14","6 Nations","Champions Cup","Coupe du Monde Rugby","Autre"]
    },
    "nfl": {
        "name": "NFL", "icon": "nfl.png",
        "comps": ["NFL","NFL Playoffs","Super Bowl","Autre"]
    },
    "cycling": {
        "name": "Cyclisme", "icon": "cycling.png",
        "comps": ["Tour de France","Giro","Vuelta","Paris-Roubaix","Classiques","Autre"]
    },
}

SPORT_COLORS = {
    "football":"seagreen","nba":"darkorange","mma":"red","motorsport":"fuchsia",
    "tennis":"gold","rugby":"dodgerblue","nfl":"mediumpurple","cycling":"cyan"
}

# ============================================================
# CRYPTO ENGINE
# ============================================================
TABLES = [
    'Wq97wQmdlPOJBGvNnbxcDHzFj2gkYURftEKV163A5MeSp0r8IXoZTyiuCLh4as',
    'KdSiCM8nf9tIbwDzH04X325O67mRuBFNWkQvVTEcpexGy1agZYqAPLsUolJjrh',
    '9Y6kURti4gzhCIGwZM0PpBXuoVcl3e5Ky7fNFSTjms8AbHErxWDO2dnLaJQvq1',
    'AfEeszp0ZRgJuqtyGOokvFjhHPrVb4cB2NIXnU6KxaS8dlQ57TLCi39wMWY1Dm',
    'yBhlVjFDA1EKYuoGZ2NqnxUesdMS3Ofp0arzwtRIc8kb9JPQ4WH5Tvg6iCX7mL',
    'wTfLtya01MnzeYSW9d4FoHcNkJZCvXQ3bgiGpEu825RrjP7OVKUxDqAIlsBh6m',
    'ButrYenv6fX9NmCUI3Rs2V7hTAWHDkKglLc50jFQOpSPqy8w1EiZ4abJGodMzx',
    '2gcSr0w8YeiXM4sAd6uxthnbqJ9BpQO7ZzKG3HTFUIVjlkEvL1oWRNmDyC5afP',
    'R3ExPNnUhDyujmK4LAMVd52vIZtplqiHragzoekJ1TSb9W6GcOYfFBC0X87Qsw',
    'ZgtAmxakYKD0zpcsqLT9wHndP5B4Ir2huCRFQfb8M67UlVN3eGyvOEjWSJoiX1',
    'YZt86WeN3ECKHA1x9vdhF4jzISL2RGurgpPsDwlJ7n0mOaBoyMUVcfib5TkXqQ',
    'uhl8iYHO6poTIvgDQ904PayfcrZ1J5zkmREFLVqBsUdNMxj7XCnGwtbW3AeKS2',
    'VaU8utB2lSwpNq0yHhF7RMTJncDbIZYXs9dAiCzmj613QxOEW4PgfGL5oKvrek',
    'zOFWr7JetVh0yN6vslDxn24fwHukXmEUj5qCSTRbgiYQPIZAM1aGL9dB8oKc3p',
    'kM1AUuqnNfrKWRj0tOzm7C9lYShZGcQBL5J4DyF3wXT2aEd8VvoPHpbiexgsI6',
    '9HYjEcLTutQpI0rO3M75ZvwA4GFK2koqzhUiCny6xNSdmRfJegDaVBXbs1PW8l',
    '0UScdanhjeNVLrFXpx3wOD7ikZ4PBsmzJM8QI5RoyqWAtfEvY1l926TuHKCgGb',
    'Bb3cNFeDkW5fwvVJm2QzgPiUL9nTZE4apdMSIqHhlxYrjC0AoK81uXRsOtGy76',
    'n4tmQckyLRd13vPebl9EzhBa0MKXGj7NUf26CH8r5AFYWOopuxSDZwsiVIqJgT',
    'ceQ68PDBs4huny23trq7ClvFWiAKHzZ1bgURwo9pXIOxdLNYVSkEfa0GJ5jmMT',
    'jxMyhCUpStFgzs81lBvrXEOHAK6PbwiRDNd4ZTJ2oI03Lk9mucaY5V7WnQefGq',
    'j4vcoE9lfpNwTsiDRQCdUbYu5k28JBWH7SeZrqyh3L6PxKGAXVOnm1tFIMazg0',
    'Xk4teWwfzEBR9bHuUZoJ3Y0NxQO8phmGT1aFiyncj7KLqvPIrAlDsSC256dgVM',
    'mWKyZVEilfpHD752LJRGvQuqIe0MawOnP81BFz69khdCSUsXjc4NYg3xrtboTA',
    '8LzXWwKhl2oGdTYAM6yIaJ3bBce4fsg9rUuQktCxpi7VD0OZPnvFNSEHqmRj15',
    'kopQbKsUMz4FCn0aqwyNAc23DlET7GWSfmd1IHO8PtevxrV6ZLghjYRXBJu5i9',
    'rz5wTkpAKgYH32OuRl4nD0yNQva186FM7eJiScBIXhbVsdUE9oGqxPCtjLmWfZ',
    'H5KQUnLCvgWSYOka3PFAjhJ0cw61z2yR8tqmMXIlsupeZfoVNxT74EirdbDBG9',
    'zvlEitNwd0bPqasYDArjgnJKIOoCSp589mM2TFy6WZk1RuxGBQL3hX7cHfeVU4',
    'd5hjmCsA34nZu9pV76Sbz1NRYO8iFGlTLcMqUxHBgKvofXawDytIkeEWQPrJ02',
]

def _rb(n):
    return (((n & 0xf) * 16 + (n >> 4)) ^ 0xff)

def _nd(txt):
    return _rb(sum(ord(c) for c in txt)) % 70

def decrypt_paste_id(enc):
    try:
        ck = int(enc[-1], 16); body = enc[:-1]
    except:
        return enc
    for rot in range(1, 16):
        tb = TABLES[rot - 1]; v = 0; dec = ""; ok = True
        for i, c in enumerate(body):
            if c not in tb: ok = False; break
            v += ord(c)
            dec += tb[(tb.index(c) - ((i + 1) * rot)) % len(tb)]
        if ok:
            t = _rb(v & 0xff); t &= 0xf; t ^= rot
            if t == ck: return dec
    return enc

def decrypt_content(text, decal):
    tb = TABLES[decal % len(TABLES)]
    lines = text.strip().split("\n"); out = []
    for line in lines:
        r = ""
        for i, c in enumerate(line):
            if c in tb:
                r += tb[(tb.index(c) - decal - i) % len(tb)]
            else:
                r += c
        out.append(r)
    return out

def decrypt_rentry(encrypted_id, raw_content):
    """Full decrypt: ID -> decal -> content"""
    real_id = decrypt_paste_id(encrypted_id)
    decal = _nd(real_id)
    return decrypt_content(raw_content, decal), real_id

# ============================================================
# RENTRY CLIENT
# ============================================================
RENTRY_BASE = "https://rentry.org"

def rentry_raw(page_id):
    """Get raw content of a rentry paste"""
    try:
        # Method 1: /raw/ endpoint (cleanest - returns source text)
        for endpoint in ["%s/raw/%s" % (RENTRY_BASE, page_id),
                         "%s/%s/raw" % (RENTRY_BASE, page_id)]:
            try:
                r = requests.get(endpoint, timeout=10,
                                 headers={"User-Agent": "Mozilla/5.0"})
                log("rentry_raw: %s -> status=%d, len=%d" % (endpoint, r.status_code, len(r.text)))
                if r.status_code == 200 and r.text.strip():
                    text = r.text.strip()
                    if text.startswith('<!') or text.startswith('<html'):
                        log("rentry_raw: /raw/ returned HTML page, skipping")
                        continue
                    if '<pre>' in text or '<body>' in text:
                        import html as htmlmod
                        text = re.sub(r'<br\s*/?>', '\n', text)
                        text = re.sub(r'<[^>]+>', '', text)
                        text = htmlmod.unescape(text).strip()
                        log("rentry_raw: stripped HTML wrapper, len=%d" % len(text))
                    lines = text.split('\n')
                    log("rentry_raw: got %d lines via /raw/" % len(lines))
                    if text and len(text) > 2:
                        return text
            except Exception as e:
                log("rentry_raw: %s error: %s" % (endpoint, str(e)))
        # Method 2: scrape HTML page (fallback)
        log("rentry_raw: trying HTML scrape for %s" % page_id)
        r = requests.get("%s/%s" % (RENTRY_BASE, page_id), timeout=10,
                         headers={"User-Agent": "Mozilla/5.0"})
        log("rentry_raw: HTML page status=%d, len=%d" % (r.status_code, len(r.text)))
        for pat in [r'<div class="entry-text"[^>]*>(.*?)</div>',
                    r'<pre[^>]*>(.*?)</pre>',
                    r'<div\s+class="plaintext"\s*>(.*?)</div>',
                    r'<article[^>]*>(.*?)</article>']:
            m = re.search(pat, r.text, re.DOTALL)
            if m:
                import html as htmlmod
                txt = re.sub(r'<br\s*/?>', '\n', m.group(1))
                txt = re.sub(r'<p[^>]*>', '', txt)
                txt = re.sub(r'</p>', '\n', txt)
                txt = re.sub(r'<[^>]+>', '', txt)
                txt = htmlmod.unescape(txt).strip()
                lines = txt.split('\n')
                log("rentry_raw: scraped %d lines via pattern %s" % (len(lines), pat[:30]))
                if txt and len(txt) > 2:
                    return txt
    except Exception as e:
        log("rentry_raw error: %s" % str(e))
    return ""

# ============================================================
# PARSE EVENTS FROM DECRYPTED CONTENT
# ============================================================
def parse_events(lines, source_id=""):
    """
    Parse pipe-separated lines into event dicts.
    Format: title|sport|competition|date|team1|team2|session|links
    session = sous-evenement (EL1, Course, Round 1, etc.) - peut etre vide
    links = url@host#quality#audio,url2@host2#quality2#audio2
    """
    events = []
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#"): continue
        p = line.split("|")
        if len(p) < 4: continue
        ev = {
            "title": p[0].strip(),
            "sport": p[1].strip() if len(p) > 1 else "",
            "competition": p[2].strip() if len(p) > 2 else "",
            "date": p[3].strip() if len(p) > 3 else "",
            "team1": p[4].strip() if len(p) > 4 else "",
            "team2": p[5].strip() if len(p) > 5 else "",
            "session": p[6].strip() if len(p) > 6 else "",
            "links": [],
            "source_rentry": source_id,
        }
        if len(p) > 7:
            for lk in p[7].split(","):
                lk = lk.strip()
                if not lk: continue
                link = {"url": "", "host": "", "quality": "", "audio": ""}
                parts = lk
                # Extract quality and audio from #tags
                tags = []
                while "#" in parts:
                    parts, tag = parts.rsplit("#", 1)
                    tags.insert(0, tag)
                # Extract host from @
                if "@" in parts:
                    url, host = parts.rsplit("@", 1)
                    link["url"] = url; link["host"] = host
                else:
                    link["url"] = parts
                if len(tags) >= 1: link["quality"] = tags[0]
                if len(tags) >= 2: link["audio"] = tags[1]
                if link["url"]: ev["links"].append(link)
        events.append(ev)
    return events

# ============================================================
# DATABASE
# ============================================================
def init_db():
    cnx = sqlite3.connect(DB_PATH); c = cnx.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT, sport TEXT, competition TEXT, date TEXT,
        team1 TEXT DEFAULT '', team2 TEXT DEFAULT '',
        session TEXT DEFAULT '',
        source_rentry TEXT DEFAULT '',
        added TEXT DEFAULT ''
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS links (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        event_id INTEGER, url TEXT, host TEXT DEFAULT '',
        quality TEXT DEFAULT '', audio TEXT DEFAULT '',
        FOREIGN KEY(event_id) REFERENCES events(id) ON DELETE CASCADE
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS rentry_index (
        rentry_id TEXT PRIMARY KEY,
        status TEXT DEFAULT 'open',
        last_import TEXT DEFAULT ''
    )""")
    c.execute("CREATE INDEX IF NOT EXISTS idx_ev_sport ON events(sport)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_ev_comp ON events(competition)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_ev_src ON events(source_rentry)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_lk_ev ON links(event_id)")
    cnx.commit(); c.close(); cnx.close()

def import_events(events, source_rentry=""):
    """Import events, replacing all from same source_rentry"""
    cnx = sqlite3.connect(DB_PATH); c = cnx.cursor()
    if source_rentry:
        # Delete old events from this source
        c.execute("SELECT id FROM events WHERE source_rentry=?", (source_rentry,))
        old_ids = [r[0] for r in c.fetchall()]
        if old_ids:
            c.executemany("DELETE FROM links WHERE event_id=?", [(i,) for i in old_ids])
            c.execute("DELETE FROM events WHERE source_rentry=?", (source_rentry,))
    count = 0
    for ev in events:
        c.execute("""INSERT INTO events (title,sport,competition,date,team1,team2,session,source_rentry,added)
            VALUES (?,?,?,?,?,?,?,?,?)""",
            (ev["title"], ev["sport"], ev["competition"], ev["date"],
             ev.get("team1",""), ev.get("team2",""), ev.get("session",""),
             ev.get("source_rentry", source_rentry), datetime.now().isoformat()))
        eid = c.lastrowid
        for lk in ev.get("links", []):
            c.execute("INSERT INTO links (event_id,url,host,quality,audio) VALUES (?,?,?,?,?)",
                (eid, lk["url"], lk.get("host",""), lk.get("quality",""), lk.get("audio","")))
        count += 1
    cnx.commit(); c.close(); cnx.close()
    return count

def update_rentry_status(rentry_id, status):
    cnx = sqlite3.connect(DB_PATH); c = cnx.cursor()
    c.execute("INSERT OR REPLACE INTO rentry_index (rentry_id,status,last_import) VALUES (?,?,?)",
              (rentry_id, status, datetime.now().isoformat()))
    cnx.commit(); c.close(); cnx.close()

def get_rentry_status(rentry_id):
    cnx = sqlite3.connect(DB_PATH); c = cnx.cursor()
    c.execute("SELECT status FROM rentry_index WHERE rentry_id=?", (rentry_id,))
    r = c.fetchone(); c.close(); cnx.close()
    return r[0] if r else None

def get_events(sport=None, comp=None, search=None, limit=50, offset=0):
    cnx = sqlite3.connect(DB_PATH); c = cnx.cursor()
    w = []; p = []
    if sport: w.append("sport=?"); p.append(sport)
    if comp: w.append("competition=? COLLATE NOCASE"); p.append(comp)
    if search:
        w.append("(title LIKE ? OR team1 LIKE ? OR team2 LIKE ? OR competition LIKE ? OR session LIKE ?)")
        s = "%%%s%%" % search; p.extend([s,s,s,s,s])
    where = ("WHERE " + " AND ".join(w)) if w else ""
    c.execute("SELECT * FROM events %s ORDER BY date DESC LIMIT ? OFFSET ?" % where, p + [limit, offset])
    rows = c.fetchall(); c.close(); cnx.close()
    return rows

def get_event(eid):
    cnx = sqlite3.connect(DB_PATH); c = cnx.cursor()
    c.execute("SELECT * FROM events WHERE id=?", (eid,))
    r = c.fetchone(); c.close(); cnx.close()
    return r

def get_links(eid):
    cnx = sqlite3.connect(DB_PATH); c = cnx.cursor()
    c.execute("SELECT * FROM links WHERE event_id=? ORDER BY quality DESC", (eid,))
    rows = c.fetchall(); c.close(); cnx.close()
    return rows

def count_links(eids):
    """Count unique links for one or multiple event IDs"""
    if isinstance(eids, (int, str)): eids = [int(eids)]
    try:
        cnx = sqlite3.connect(DB_PATH); c = cnx.cursor()
        ph = ",".join("?" * len(eids))
        c.execute("SELECT COUNT(DISTINCT url) FROM links WHERE event_id IN (%s)" % ph, eids)
        n = c.fetchone()[0]; c.close(); cnx.close()
        return n
    except Exception as e:
        log("count_links error: %s (eids=%s)" % (str(e), str(eids[:3])))
        return 0

def get_comps(sport):
    cnx = sqlite3.connect(DB_PATH); c = cnx.cursor()
    c.execute("SELECT competition FROM events WHERE sport=? AND competition!='' GROUP BY competition COLLATE NOCASE ORDER BY competition COLLATE NOCASE", (sport,))
    r = [x[0] for x in c.fetchall()]; c.close(); cnx.close()
    return r

def get_sessions(sport=None, comp=None, title_base=None):
    """Get sessions/sub-events for a parent event"""
    cnx = sqlite3.connect(DB_PATH); c = cnx.cursor()
    w = ["session!=''"]
    p = []
    if sport: w.append("sport=?"); p.append(sport)
    if comp: w.append("competition=? COLLATE NOCASE"); p.append(comp)
    if title_base: w.append("title=?"); p.append(title_base)
    c.execute("SELECT * FROM events WHERE %s ORDER BY date, session" % " AND ".join(w), p)
    rows = c.fetchall(); c.close(); cnx.close()
    return rows

def count_events(sport=None):
    cnx = sqlite3.connect(DB_PATH); c = cnx.cursor()
    if sport:
        c.execute("SELECT COUNT(*) FROM events WHERE sport=?", (sport,))
    else:
        c.execute("SELECT COUNT(*) FROM events")
    n = c.fetchone()[0]; c.close(); cnx.close()
    return n

def reset_database():
    cnx = sqlite3.connect(DB_PATH); c = cnx.cursor()
    for t in ("links","events","rentry_index"): c.execute("DROP TABLE IF EXISTS %s" % t)
    cnx.commit(); c.close(); cnx.close()
    init_db()

# ============================================================
# DEBRID
# ============================================================
class AllDebridClient:
    BASE = "https://api.alldebrid.com/v4.1"
    def __init__(self, key, proxy=""):
        self.key = key; self.s = requests.Session()
        if proxy: self.s.proxies = {"http": proxy, "https": proxy}
    def unlock(self, link):
        r = self.s.get("%s/link/unlock" % self.BASE,
            params={"agent": "sportplay", "apikey": self.key, "link": link}, timeout=15).json()
        if r.get("status") == "success":
            return True, r["data"]["link"]
        return False, r.get("error", {}).get("message", "Erreur")
    def magnet_upload(self, mag):
        r = self.s.post("%s/magnet/upload" % self.BASE,
            params={"agent": "sportplay", "apikey": self.key},
            data=[("magnets[]", mag)], timeout=15).json()
        if r.get("status") == "success" and r["data"]["magnets"]:
            return True, r["data"]["magnets"][0]["id"]
        return False, "Erreur magnet"
    def magnet_status(self, mid):
        return self.s.get("%s/magnet/status" % self.BASE,
            params={"agent": "sportplay", "apikey": self.key, "id": mid}, timeout=15).json()
    def magnet_delete(self, mid):
        try:
            self.s.get("%s/magnet/delete" % self.BASE,
                params={"agent": "sportplay", "apikey": self.key, "id": mid}, timeout=10)
        except: pass
    def magnet_instant(self, mag):
        """Check if magnet is instantly available (cached)"""
        try:
            r = self.s.get("%s/magnet/instant" % self.BASE,
                params={"agent": "sportplay", "apikey": self.key, "magnets[]": mag}, timeout=10).json()
            if r.get("status") == "success":
                data = r.get("data", {}).get("magnets", [])
                if data and data[0].get("instant", False):
                    return True
        except: pass
        return False
    def magnet_links(self, mag, timeout_secs=90):
        ok, mid = self.magnet_upload(mag)
        if not ok: return [], None
        max_polls = timeout_secs // 2
        for _ in range(max_polls):
            st = self.magnet_status(mid)
            md = st.get("data", {}).get("magnets", {})
            if md.get("status") == "Ready":
                raw = self._extract(md.get("files", []))
                out = []
                for r in raw:
                    try:
                        ok2, direct = self.unlock(r["url"])
                        if ok2:
                            out.append({"url": direct, "name": r["name"], "size": r["size"]})
                    except Exception as e:
                        log("AllDebrid unlock error: %s" % str(e))
                return out, mid
            elif md.get("status") in ("error", "Error"):
                self.magnet_delete(mid)
                return [], None
            time.sleep(2)
        # Timeout - cleanup
        self.magnet_delete(mid)
        return [], None
    def _extract(self, entries, minsize=5_000_000):
        links = []
        for e in entries:
            if "e" in e: links.extend(self._extract(e["e"], minsize))
            elif e.get("s", 0) >= minsize and e.get("l"):
                links.append({"url": e["l"], "name": e.get("n",""), "size": e.get("s",0)})
        return links

class RealDebridClient:
    BASE = "https://api.real-debrid.com/rest/1.0"
    def __init__(self, key, proxy=""):
        self.s = requests.Session()
        self.s.headers.update({"Authorization": "Bearer %s" % key})
        if proxy: self.s.proxies = {"http": proxy, "https": proxy}
    def unlock(self, link):
        r = self.s.post("%s/unrestrict/link" % self.BASE, data={"link": link}, timeout=15).json()
        if "download" in r: return True, r["download"]
        return False, r.get("error", "Erreur")
    def magnet_delete(self, mid):
        try:
            self.s.delete("%s/torrents/delete/%s" % (self.BASE, mid), timeout=10)
        except: pass
    def magnet_links(self, mag, timeout_secs=90):
        if not mag.startswith("magnet:"): mag = "magnet:?xt=urn:btih:%s" % mag
        r = self.s.post("%s/torrents/addMagnet" % self.BASE, data={"magnet": mag}, timeout=15).json()
        if "id" not in r: return [], None
        tid = r["id"]
        self.s.post("%s/torrents/selectFiles/%s" % (self.BASE, tid), data={"files": "all"})
        max_polls = timeout_secs // 2
        for _ in range(max_polls):
            info = self.s.get("%s/torrents/info/%s" % (self.BASE, tid), timeout=15).json()
            if info.get("status") == "downloaded":
                out = []
                for lk in info.get("links", []):
                    ok, dl = self.unlock(lk)
                    if ok: out.append({"url": dl, "name": info.get("filename",""), "size": info.get("bytes",0)})
                return out, tid
            elif info.get("status") in ("error","dead","magnet_error"):
                self.magnet_delete(tid)
                return [], None
            time.sleep(2)
        self.magnet_delete(tid)
        return [], None

def get_debrid():
    svc = S("debrid_service", "AllDebrid")
    proxy = S("proxy_url") if SB("use_proxy") else ""
    if svc == "AllDebrid":
        key = S("key_alldebrid")
        if key: return AllDebridClient(key, proxy), "AllDebrid"
    elif svc == "RealDebrid":
        key = S("key_realdebrid")
        if key: return RealDebridClient(key, proxy), "RealDebrid"
    return None, "none"

def debrid_link(url):
    client, svc = get_debrid()
    if not client: notify_err("Pas de debrideur configure!"); return None
    ok, result = client.unlock(url)
    if ok: return result
    notify_err("Erreur %s: %s" % (svc, result)); return None

# ============================================================
# UPDATE ENGINE
# ============================================================
def count_events_by_source(source):
    """Count events from a specific source rentry"""
    cnx = sqlite3.connect(DB_PATH); c = cnx.cursor()
    c.execute("SELECT COUNT(*) FROM events WHERE source_rentry=?", (source,))
    n = c.fetchone()[0]; c.close(); cnx.close()
    return n

def do_update(force=False):
    """
    Read master rentry -> for each child rentry:
    - full + already imported -> skip (unless force)
    - open -> always reimport
    - unknown -> import
    """
    master_enc = S("master_rentry_enc")
    if not master_enc:
        log("No master rentry configured")
        return 0

    # Decrypt master rentry ID
    master_real = decrypt_paste_id(master_enc)
    log("Update: master real ID = %s" % master_real)

    # Fetch master rentry raw content
    raw_master = rentry_raw(master_real)
    if not raw_master:
        log("Update: could not fetch master rentry")
        return 0

    # Decrypt master content
    decal = _nd(master_real)
    master_lines = decrypt_content(raw_master, decal)
    log("Update: master has %d lines" % len(master_lines))

    total = 0
    total_new = 0
    for line in master_lines:
        line = line.strip()
        if not line or line.startswith("#"): continue
        parts = line.split("|")
        child_enc = parts[0].strip()
        child_status = parts[1].strip() if len(parts) > 1 else "open"

        # Check if already imported
        local_status = get_rentry_status(child_enc)

        if child_status == "full" and local_status == "full" and not force:
            log("Skip full rentry: %s" % child_enc)
            continue

        if child_status == "full" and local_status == "full" and force:
            pass  # force reimport

        # Decrypt child rentry ID
        child_real = decrypt_paste_id(child_enc)
        log("Importing rentry: %s (real: %s, status: %s)" % (child_enc, child_real, child_status))

        # Fetch and decrypt child content
        raw_child = rentry_raw(child_real)
        if not raw_child:
            log("Could not fetch child rentry: %s" % child_real)
            continue

        child_decal = _nd(child_real)
        child_lines = decrypt_content(raw_child, child_decal)

        # Parse and import
        events = parse_events(child_lines, source_id=child_enc)
        if events:
            # Count existing events before import
            old_count = count_events_by_source(child_enc)
            count = import_events(events, source_rentry=child_enc)
            update_rentry_status(child_enc, child_status)
            new_count = max(0, count - old_count)
            log("Imported %d events from %s (%d new)" % (count, child_enc, new_count))
            total += count
            total_new += new_count
        else:
            log("No events found in %s" % child_enc)

    return total, total_new

# ============================================================
# QUALITY HELPERS
# ============================================================
def quality_color(q):
    return {"2160p":"red","1080p":"fuchsia","720p":"seagreen","480p":"dodgerblue"}.get(q, "white")

def parse_release(name):
    n = re.sub(r'[\s_\-\[\]\(\)]+', '.', name.upper())
    q = "Unknown"
    for pat, val in [(r'2160|4K|UHD',"2160p"),(r'1080',"1080p"),(r'720',"720p"),(r'480',"480p")]:
        if re.search(pat, n): q = val; break
    return q
