# -*- coding: utf-8 -*-
"""SportPlay v2 - Point d'entree"""
import sys
from urllib.parse import parse_qsl, urlencode, quote, unquote
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
from lib import *

# ============================================================
# MENUS
# ============================================================
def menu_main():
    h = HANDLE()
    xbmcplugin.setPluginCategory(h, "SportPlay")
    for key, sp in SPORTS.items():
        n = count_events(key)
        label = sp["name"]
        if n: label += " [COLOR grey](%d)[/COLOR]" % n
        add_item(label, "sport", {"k": key}, icon=sp.get("icon",""), fanart=get_sport_fanart(key))
    add_item("[COLOR yellow]--- Outils ---[/COLOR]", "noop", folder=False)
    add_item("[COLOR grey]Mise a jour[/COLOR]", "force_update", folder=False)
    add_item("[COLOR grey]Parametres[/COLOR]", "settings", folder=False)
    end_dir()

def menu_sport(params):
    h = HANDLE()
    key = params["k"]
    sp = SPORTS.get(key)
    if not sp: return
    xbmcplugin.setPluginCategory(h, sp["name"])
    fan = get_sport_fanart(key)
    add_item("[COLOR lime]Tous[/COLOR]", "list", {"sport": key}, icon=sp.get("icon",""), fanart=fan)
    # Competitions from DB
    for comp in get_comps(key):
        add_item("[COLOR gold]%s[/COLOR]" % comp, "list", {"sport": key, "comp": comp},
                 icon=(COMP_ICONS.get(comp, "") + ".png") if COMP_ICONS.get(comp) else "", fanart=fan)
    end_dir()

def menu_list(params):
    h = HANDLE()
    sport = params.get("sport")
    comp = params.get("comp")
    search = params.get("q")
    page = int(params.get("page", "0"))
    nbi = SI("nb_items", 50)

    rows = get_events(sport=sport, comp=comp, search=search, limit=nbi, offset=page * nbi)
    title = "Evenements"
    if sport and sport in SPORTS: title = SPORTS[sport]["name"]
    if comp: title += " - %s" % comp
    xbmcplugin.setPluginCategory(h, title)
    xbmcplugin.setContent(h, "videos")

    # Group events by title: same title = one entry, sessions merged
    from collections import OrderedDict
    grouped = OrderedDict()
    for ev in rows:
        eid, etitle, esport, ecomp, edate = ev[0], ev[1], ev[2], ev[3], ev[4]
        et1, et2, esess = ev[5], ev[6], ev[7]
        key = "%s|%s" % (ecomp, etitle)
        if key not in grouped:
            grouped[key] = {"title": etitle, "sport": esport, "comp": ecomp,
                            "date": edate, "t1": et1, "t2": et2, "sessions": []}
        grouped[key]["sessions"].append({"eid": eid, "session": esess})

    for key, g in grouped.items():
        col = SPORT_COLORS.get(g["sport"], "white")
        _ev_icon = get_comp_icon(g.get("comp", ""))
        _ev_fan = get_sport_fanart(g.get("sport", ""))
        if len(g["sessions"]) == 1 and not g["sessions"][0]["session"]:
            # Single event, no session: go directly to links
            eid = g["sessions"][0]["eid"]
            nlk = count_links(eid)
            label_parts = []
            if g["date"]: label_parts.append("[COLOR grey]%s[/COLOR]" % g["date"])
            if g["comp"]: label_parts.append("[COLOR gold]%s[/COLOR]" % g["comp"])
            if g["t1"] and g["t2"]:
                auto = "%s vs %s" % (g["t1"], g["t2"])
                if g["title"] and g["title"].lower() != auto.lower():
                    label_parts.append("%s - %s" % (g["title"], auto))
                else:
                    label_parts.append(auto)
            else:
                label_parts.append(g["title"])
            if nlk: label_parts.append("[COLOR grey](%d %s)[/COLOR]" % (nlk, "lien" if nlk == 1 else "liens"))
            label = " - ".join(label_parts)
            li = xbmcgui.ListItem(label=label)
            set_info(li, {"title": label, "plot": "%s %s" % (g["comp"], g["date"]), "mediatype": "video"})
            li.setArt({"thumb": _ev_icon, "icon": _ev_icon, "fanart": _ev_fan})
            url = sys.argv[0] + "?" + urlencode({"action": "links", "eid": str(eid), "title": g["title"]})
            xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=True)
        elif len(g["sessions"]) == 1:
            # Single event with session: show session in label, go to links
            s = g["sessions"][0]
            nlk = count_links(s["eid"])
            label_parts = []
            if g["date"]: label_parts.append("[COLOR grey]%s[/COLOR]" % g["date"])
            if g["comp"]: label_parts.append("[COLOR gold]%s[/COLOR]" % g["comp"])
            if s["session"]: label_parts.append("[COLOR cyan]%s[/COLOR]" % s["session"])
            if g["t1"] and g["t2"]:
                auto = "%s vs %s" % (g["t1"], g["t2"])
                if g["title"] and g["title"].lower() != auto.lower():
                    label_parts.append("%s - %s" % (g["title"], auto))
                else:
                    label_parts.append(auto)
            else:
                label_parts.append(g["title"])
            if nlk: label_parts.append("[COLOR grey](%d %s)[/COLOR]" % (nlk, "lien" if nlk == 1 else "liens"))
            label = " - ".join(label_parts)
            li = xbmcgui.ListItem(label=label)
            set_info(li, {"title": label, "mediatype": "video"})
            li.setArt({"thumb": _ev_icon, "icon": _ev_icon, "fanart": _ev_fan})
            url = sys.argv[0] + "?" + urlencode({"action": "links", "eid": str(s["eid"]), "title": g["title"]})
            xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=True)
        else:
            # Multiple sessions: show parent, clicking opens session list
            has_sessions = any(s["session"] for s in g["sessions"])
            if has_sessions:
                all_eids = [s["eid"] for s in g["sessions"]]
                nlk = count_links(all_eids)
                label_parts = []
                if g["date"]: label_parts.append("[COLOR grey]%s[/COLOR]" % g["date"])
                if g["comp"]: label_parts.append("[COLOR gold]%s[/COLOR]" % g["comp"])
                label_parts.append(g["title"])

                if nlk: label_parts.append("[COLOR grey](%d %s)[/COLOR]" % (nlk, "lien" if nlk == 1 else "liens"))
                label = " - ".join(label_parts)
                li = xbmcgui.ListItem(label=label)
                set_info(li, {"title": label, "mediatype": "video"})
                li.setArt({"thumb": _ev_icon, "icon": _ev_icon, "fanart": _ev_fan})
                eids = ",".join(str(s["eid"]) for s in g["sessions"])
                url = sys.argv[0] + "?" + urlencode({"action": "sessions", "eids": eids, "title": g["title"]})
                xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=True)
            else:
                # Same title, no sessions: merge all links under one entry
                eid = g["sessions"][0]["eid"]
                all_eids = [s["eid"] for s in g["sessions"]]
                nlk = count_links(all_eids)
                label_parts = []
                if g["date"]: label_parts.append("[COLOR grey]%s[/COLOR]" % g["date"])
                if g["comp"]: label_parts.append("[COLOR gold]%s[/COLOR]" % g["comp"])
                if g["t1"] and g["t2"]:
                    label_parts.append("%s vs %s" % (g["t1"], g["t2"]))
                else:
                    label_parts.append(g["title"])
                if nlk: label_parts.append("[COLOR grey](%d %s)[/COLOR]" % (nlk, "lien" if nlk == 1 else "liens"))
                label = " - ".join(label_parts)
                li = xbmcgui.ListItem(label=label)
                set_info(li, {"title": label, "mediatype": "video"})
                li.setArt({"thumb": _ev_icon, "icon": _ev_icon, "fanart": _ev_fan})
                eids = ",".join(str(s["eid"]) for s in g["sessions"])
                url = sys.argv[0] + "?" + urlencode({"action": "links_multi", "eids": eids, "title": g["title"]})
                xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=True)

    if len(rows) == nbi:
        np = dict(params); np["page"] = str(page + 1)
        add_item("[COLOR yellow]Page suivante (%d)...[/COLOR]" % (page + 2), "list", np)

    end_dir("videos", [xbmcplugin.SORT_METHOD_UNSORTED, xbmcplugin.SORT_METHOD_LABEL])

def menu_links(params):
    h = HANDLE()
    eid = int(params.get("eid", 0))
    title = params.get("title", "")
    # Get sport/comp for icons
    _lk_icon = ADDON.getAddonInfo("icon")
    _lk_fan = ADDON.getAddonInfo("fanart")
    _ev_data = get_event(eid)
    if _ev_data:
        _lk_icon = get_comp_icon(_ev_data[3] or "")
        _lk_fan = get_sport_fanart(_ev_data[2] or "")
    links = get_links(eid)
    # Dedup by URL
    seen = set()
    unique_links = []
    for lk in links:
        if lk[2] not in seen:
            seen.add(lk[2])
            unique_links.append(lk)
    links = unique_links
    if not links:
        notify("Aucun lien disponible"); return

    xbmcplugin.setPluginCategory(h, title)
    xbmcplugin.setContent(h, "videos")

    # Autoplay?
    if SB("autoplay"):
        pref = S("preferred_quality", "1080p")
        best = None
        for lk in links:
            if pref in (lk[4] or ""):
                best = lk; break
        if not best: best = links[0]
        _play({"url": best[2], "title": title}); return

    for lk in links:
        # lk: id, event_id, url, host, quality, audio
        url, host, quality, audio = lk[2], lk[3], lk[4], lk[5]
        col = quality_color(quality)
        parts = ["[COLOR %s][%s][/COLOR]" % (col, quality or "?")]
        if audio: parts.append("[%s]" % audio)
        if host: parts.append("[%s]" % host)
        label = " ".join(parts)

        li = xbmcgui.ListItem(label=label)
        li.setProperty("IsPlayable", "true")
        set_info(li, {"title": title, "mediatype": "video"})
        li.setArt({"thumb": _lk_icon, "icon": _lk_icon, "fanart": _lk_fan})

        is_magnet = url.startswith("magnet:") or (len(url) == 40 and re.match(r'^[a-fA-F0-9]+$', url))
        act = "play_magnet" if is_magnet else "play"
        purl = sys.argv[0] + "?" + urlencode({"action": act, "url": url, "title": title})
        xbmcplugin.addDirectoryItem(handle=h, url=purl, listitem=li, isFolder=False)

    end_dir("videos")

def menu_sessions(params):
    """Show sessions for a grouped event - merge same session names"""
    h = HANDLE()
    eids = params.get("eids", "").split(",")
    title = params.get("title", "")
    xbmcplugin.setPluginCategory(h, title)
    xbmcplugin.setContent(h, "videos")
    # Get sport/comp from first event for icons
    _sess_icon = ADDON.getAddonInfo("icon")
    _sess_fan = ADDON.getAddonInfo("fanart")
    try:
        _first = get_event(int(eids[0]))
        if _first:
            _sess_icon = get_comp_icon(_first[3] or "")
            _sess_fan = get_sport_fanart(_first[2] or "")
    except: pass

    # Group by session name to avoid duplicates
    from collections import OrderedDict
    sess_map = OrderedDict()
    for eid_s in eids:
        try:
            eid = int(eid_s)
        except:
            continue
        ev = get_event(eid)
        if not ev: continue
        sess = ev[7] or "Liens"
        if sess not in sess_map:
            sess_map[sess] = []
        sess_map[sess].append(eid)

    for sess, sess_eids in sess_map.items():
        # Count unique links (dedup by URL)
        seen_urls = set()
        for eid in sess_eids:
            for lk in get_links(eid):
                seen_urls.add(lk[2])
        total_links = len(seen_urls)
        label = "[COLOR cyan]%s[/COLOR] [COLOR grey](%d liens)[/COLOR]" % (sess, total_links)
        li = xbmcgui.ListItem(label=label)
        set_info(li, {"title": "%s - %s" % (title, sess), "mediatype": "video"})
        li.setArt({"thumb": _sess_icon, "icon": _sess_icon, "fanart": _sess_fan})
        if len(sess_eids) == 1:
            url = sys.argv[0] + "?" + urlencode({"action": "links", "eid": str(sess_eids[0]), "title": "%s - %s" % (title, sess)})
        else:
            url = sys.argv[0] + "?" + urlencode({"action": "links_multi", "eids": ",".join(str(e) for e in sess_eids), "title": "%s - %s" % (title, sess)})
        xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=True)

    end_dir("videos")

def menu_links_multi(params):
    """Show links from multiple events merged (same title, no sessions) - dedup by URL"""
    h = HANDLE()
    eids = params.get("eids", "").split(",")
    title = params.get("title", "")
    xbmcplugin.setPluginCategory(h, title)
    xbmcplugin.setContent(h, "videos")
    _ml_icon = ADDON.getAddonInfo("icon")
    _ml_fan = ADDON.getAddonInfo("fanart")
    try:
        _first = get_event(int(eids[0]))
        if _first:
            _ml_icon = get_comp_icon(_first[3] or "")
            _ml_fan = get_sport_fanart(_first[2] or "")
    except: pass

    all_links = []
    seen_urls = set()
    for eid_s in eids:
        try:
            for lk in get_links(int(eid_s)):
                if lk[2] not in seen_urls:
                    seen_urls.add(lk[2])
                    all_links.append(lk)
        except:
            pass

    if not all_links:
        notify("Aucun lien"); return

    for lk in all_links:
        url, host, quality, audio = lk[2], lk[3], lk[4], lk[5]
        col = quality_color(quality)
        parts = ["[COLOR %s][%s][/COLOR]" % (col, quality or "?")]
        if audio: parts.append("[%s]" % audio)
        if host: parts.append("[%s]" % host)
        label = " ".join(parts)

        li = xbmcgui.ListItem(label=label)
        li.setProperty("IsPlayable", "true")
        set_info(li, {"title": title, "mediatype": "video"})
        li.setArt({"thumb": _ml_icon, "icon": _ml_icon, "fanart": _ml_fan})

        is_magnet = url.startswith("magnet:") or (len(url) == 40 and re.match(r'^[a-fA-F0-9]+$', url))
        act = "play_magnet" if is_magnet else "play"
        purl = sys.argv[0] + "?" + urlencode({"action": act, "url": url, "title": title})
        xbmcplugin.addDirectoryItem(handle=h, url=purl, listitem=li, isFolder=False)

    end_dir("videos")

# ============================================================
# PLAYBACK
# ============================================================
def _play(params):
    h = HANDLE()
    url = params.get("url", "")
    title = params.get("title", "Video")
    if not url: notify_err("Pas d'URL"); return

    resolved = debrid_link(url)
    if not resolved: return

    li = xbmcgui.ListItem(label=title, path=resolved)
    li.setProperty("IsPlayable", "true")
    set_info(li, {"title": title, "mediatype": "video"})
    xbmcplugin.setResolvedUrl(h, True, listitem=li)

def _play_magnet(params):
    h = HANDLE()
    url = params.get("url", "")
    title = params.get("title", "Video")

    # IMPORTANT: always cancel resolved URL immediately for magnets
    # because magnet resolution takes too long and Kodi will timeout
    xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())

    if not url: return

    if not url.startswith("magnet:") and re.match(r'^[a-fA-F0-9]{40}$', url):
        url = "magnet:?xt=urn:btih:%s" % url

    if S("torrent_player", "Debrideur") == "Elementum":
        xbmc.executebuiltin('PlayMedia(plugin://plugin.video.elementum/play?uri=%s)' % quote(url))
        return

    client, svc = get_debrid()
    if not client:
        notify_err("Pas de debrideur"); return

    dp = xbmcgui.DialogProgress()
    dp.create("SportPlay", "Resolution du magnet via %s..." % svc)

    # Check instant availability (AllDebrid only)
    is_cached = False
    if hasattr(client, 'magnet_instant'):
        dp.update(5, "Verification du cache...")
        is_cached = client.magnet_instant(url)
        if is_cached:
            dp.update(10, "En cache ! Telechargement...")
        else:
            dp.update(10, "Pas en cache, resolution en cours...")

    timeout_secs = SI("magnet_timeout", 90)
    links, magnet_id = client.magnet_links(url, timeout_secs=timeout_secs)

    dp.close()

    if not links:
        if magnet_id:
            client.magnet_delete(magnet_id)
        notify_err("Aucun fichier (timeout ou erreur)"); return

    vid_ext = ('.mkv','.mp4','.avi','.ts','.mpg','.m4v','.mov')
    vids = [l for l in links if any(l.get("name","").lower().endswith(e) for e in vid_ext)]
    if not vids: vids = links

    resolved_url = None
    resolved_name = title

    if len(vids) == 1:
        resolved_url = vids[0]["url"]
        resolved_name = vids[0].get("name", title)
    else:
        names = [v.get("name","Fichier") for v in vids]
        idx = xbmcgui.Dialog().select("Choisir le fichier", names)
        if idx >= 0:
            resolved_url = vids[idx]["url"]
            resolved_name = names[idx]

    if resolved_url:
        li = xbmcgui.ListItem(label=resolved_name, path=resolved_url)
        xbmc.Player().play(resolved_url, li)
        # Cleanup magnet after a delay (let playback start)
        if magnet_id:
            def _cleanup():
                import time as _t
                _t.sleep(10)
                try: client.magnet_delete(magnet_id)
                except: pass
            import threading
            threading.Thread(target=_cleanup, daemon=True).start()
    else:
        # User cancelled - cleanup immediately
        if magnet_id:
            try: client.magnet_delete(magnet_id)
            except: pass
# ============================================================
# SEARCH / LATEST / UPDATE
# ============================================================
def do_search(params):
    sport = params.get("sport", "")
    kb = xbmc.Keyboard("", "Rechercher")
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        menu_list({"sport": sport, "q": kb.getText(), "page": "0"})

def do_latest(params):
    menu_list({"page": "0"})

def do_force_update(params=None):
    notify("Mise a jour en cours...")
    result = do_update(force=True)
    total, new_count = result if isinstance(result, tuple) else (result, 0)
    if total > 0 and new_count > 0:
        notify("MAJ: %d evenements (%d nouveaux)" % (total, new_count))
    elif total > 0:
        notify("MAJ terminee: %d evenements" % total)
    else:
        notify("Rien de nouveau")

def do_reset(params=None):
    if xbmcgui.Dialog().yesno("SportPlay", "Reinitialiser la base ?"):
        reset_database()
        notify("Base reinitialisee")

# ============================================================
# ROUTER
# ============================================================
ROUTES = {
    "sport": menu_sport, "list": menu_list, "links": menu_links,
    "sessions": menu_sessions, "links_multi": menu_links_multi,
    "search": do_search, "latest": do_latest,
    "play": _play, "play_magnet": _play_magnet,
    "force_update": do_force_update, "reset_db": do_reset,
    "settings": lambda p: xbmcaddon.Addon().openSettings(),
    "noop": lambda p: None,
}

def router(qs):
    params = dict(parse_qsl(qs))
    log("Route: %s" % str(params))
    action = params.get("action", "")
    if action in ROUTES:
        ROUTES[action](params)
    elif not action:
        menu_main()
    else:
        notify_err("Action inconnue: %s" % action)

if __name__ == "__main__":
    init_db()
    router(sys.argv[2][1:])
