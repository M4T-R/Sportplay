# -*- coding: utf-8 -*-
"""SportPlay v2 - Service de mise a jour automatique"""
import time
import xbmc
import xbmcaddon

ADDON = xbmcaddon.Addon("plugin.video.sportplay")

def S(key, default=""):
    v = ADDON.getSetting(key); return v if v else default

def SB(key, default=False):
    v = ADDON.getSetting(key); return v.lower() != "false" if v else default

def SI(key, default=0):
    try: return int(ADDON.getSetting(key))
    except: return default

class SportPlayUpdater(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        xbmc.log("SportPlay: Updater service started", xbmc.LOGINFO)

    def run(self):
        # Wait for Kodi to fully start
        self.waitForAbort(10)

        # Update on start if enabled
        if SB("auto_update") and SB("update_on_start"):
            xbmc.log("SportPlay: Startup update", xbmc.LOGINFO)
            self._do_update()

        # Periodic updates
        interval = SI("update_interval", 30) * 60  # minutes -> seconds
        if interval < 300: interval = 300  # minimum 5 min

        while not self.abortRequested():
            if self.waitForAbort(interval):
                break  # Kodi is shutting down

            if SB("auto_update"):
                xbmc.log("SportPlay: Periodic update", xbmc.LOGINFO)
                self._do_update()

    def _do_update(self):
        try:
            from lib import init_db, do_update, notify
            init_db()
            notify("Mise a jour en cours...")
            result = do_update()
            total, new_count = result if isinstance(result, tuple) else (result, 0)
            if total > 0:
                xbmc.log("SportPlay: Updated %d events (%d new)" % (total, new_count), xbmc.LOGINFO)
                if new_count > 0:
                    notify("MAJ: %d evenements (%d nouveaux)" % (total, new_count))
                else:
                    notify("MAJ terminee: %d evenements" % total)
            else:
                notify("MAJ terminee, rien de nouveau")
        except Exception as e:
            xbmc.log("SportPlay: Update error: %s" % str(e), xbmc.LOGERROR)

if __name__ == "__main__":
    updater = SportPlayUpdater()
    updater.run()
